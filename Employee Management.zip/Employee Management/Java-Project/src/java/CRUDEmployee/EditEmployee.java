package CRUDEmployee;

import DAO.Employee;
import DAO.EmployeeDAO;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/EditEmployee")
public class EditEmployee extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the employee ID from the request parameters
        String idParam = request.getParameter("id");
        if (idParam != null) {
            try {
                int id = Integer.parseInt(idParam);
                var employee = EmployeeDAO.getEmployeeById(id);

                if (employee != null) {
                    // Forward the employee object to the JSP page
                    request.setAttribute("employee", employee);
                    RequestDispatcher dispatcher = request.getRequestDispatcher("/editEmployeeForm.jsp");
                    dispatcher.forward(request, response);
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Employee not found");
                }
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid employee ID format");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Employee ID is required");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Collect form data
        String idParam = request.getParameter("id");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String jobTitle = request.getParameter("jobTitle");
        String experienceParam = request.getParameter("experience");
        String salaryParam = request.getParameter("salary");
        String appliedDate = request.getParameter("appliedDate");

        // Validate the parameters
        if (idParam != null && name != null && email != null && jobTitle != null && experienceParam != null && salaryParam != null && appliedDate != null) {
            try {
                int id = Integer.parseInt(idParam);
                int experience = Integer.parseInt(experienceParam);
                double salary = Double.parseDouble(salaryParam);

                // Additional validation (email format, salary, etc.)
                if (!email.contains("@")) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid email format");
                    return;
                }
                if (salary <= 0) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Salary must be a positive number");
                    return;
                }
                if (experience < 0) {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Experience cannot be negative");
                    return;
                }

                // Create an employee object to update
                Employee employee = new Employee(id, name, email, jobTitle, experience, salary, appliedDate);

                // Call the method to update the employee details in the database
                boolean updated = EmployeeDAO.updateEmployee(employee);
                if (updated) {
                    response.sendRedirect("dashboard.jsp");  // Redirect to the employee list after update
                } else {
                    response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to update employee");
                }
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid data format for experience or salary");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "All fields are required");
        }
    }
}
