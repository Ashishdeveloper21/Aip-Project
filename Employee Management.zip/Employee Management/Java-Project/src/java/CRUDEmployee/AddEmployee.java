package CRUDEmployee;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.SQLException;

@WebServlet("/AddEmployee")
public class AddEmployee extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/employee_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Ashish@123";

    // ✅ Handle GET request (to avoid "GET not supported" error)
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        response.getWriter().println("<h3 style='color:red;'>Error: Use the form to submit data!</h3>");
    }

    // ✅ Handle POST request (Form submission)
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try {
            // Retrieve form parameters
            String name = request.getParameter("name");
            String email = request.getParameter("email");
            String jobTitle = request.getParameter("jobTitle");
            String appliedDate = request.getParameter("appliedDate");

            // Validate input
            if (name == null || email == null || jobTitle == null || appliedDate == null ||
                name.trim().isEmpty() || email.trim().isEmpty() || jobTitle.trim().isEmpty() || appliedDate.trim().isEmpty()) {
                response.getWriter().println("<h3 style='color:red;'>Error: All fields are required!</h3>");
                return;
            }

            // Parse experience and salary safely
            int experience;
            double salary;
            try {
                experience = Integer.parseInt(request.getParameter("experience"));
                salary = Double.parseDouble(request.getParameter("salary"));
            } catch (NumberFormatException e) {
                response.getWriter().println("<h3 style='color:red;'>Error: Invalid number format for Experience or Salary!</h3>");
                return;
            }

            // Database connection
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load MySQL driver
            try (Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement ps = con.prepareStatement("INSERT INTO employees (name, email, jobTitle, experience, salary, appliedDate) VALUES (?, ?, ?, ?, ?, ?)")) {

                // Set parameters
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, jobTitle);
                ps.setInt(4, experience);
                ps.setDouble(5, salary);
                ps.setString(6, appliedDate);

                // Execute insert
                int rowsInserted = ps.executeUpdate();
                if (rowsInserted > 0) {
                    response.sendRedirect("dashboard.jsp"); // Redirect to dashboard on success
                } else {
                    response.getWriter().println("<h3 style='color:red;'>Error: Unable to add employee!</h3>");
                }
            }
        } catch (IOException | ClassNotFoundException | SQLException e) {
            response.getWriter().println("<h3 style='color:red;'>Unexpected Error: " + e.getMessage() + "</h3>");
        }
    }
}
