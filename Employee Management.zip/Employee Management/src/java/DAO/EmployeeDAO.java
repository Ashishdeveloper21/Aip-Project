package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/employee_db";
    private static final String USER = "root";
    private static final String PASSWORD = "Ashish@123";

    private static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found.", e);
        }
    }

    public static boolean insertEmployee(Employee emp) {
        String sql = "INSERT INTO employee (id, name, email, jobtitle, experience, salary, applieddate) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, emp.getId());
            ps.setString(2, emp.getName());
            ps.setString(3, emp.getEmail());
            ps.setString(4, emp.getJobTitle());
            ps.setInt(5, emp.getExperience());
            ps.setDouble(6, emp.getSalary());
            ps.setString(7, emp.getAppliedDate());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public static List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        String query = "SELECT * FROM employees";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                employees.add(new Employee(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("jobtitle"),
                        rs.getInt("experience"),
                        rs.getDouble("salary"),
                        rs.getString("applieddate")
                ));
            }
        } catch (SQLException e) {
        }
        return employees;
    }

    public static Employee getEmployeeById(int id) {
        Employee emp = null;
        String query = "SELECT * FROM employees WHERE id = ?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(query)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    emp = new Employee(
                            rs.getInt("id"),
                            rs.getString("name"),
                            rs.getString("email"),
                            rs.getString("jobtitle"),
                            rs.getInt("experience"),
                            rs.getDouble("salary"),
                            rs.getString("applieddate")
                    );
                }
            }
        } catch (SQLException e) {
        }
        return emp;
    }

    public static boolean updateEmployee(Employee emp) {
        String sql = "UPDATE employees SET name=?, email=?, jobtitle=?, experience=?, salary=?, applieddate=? WHERE id=?";
        try (Connection conn = getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, emp.getName());
            ps.setString(2, emp.getEmail());
            ps.setString(3, emp.getJobTitle());
            ps.setInt(4, emp.getExperience());
            ps.setDouble(5, emp.getSalary());
            ps.setString(6, emp.getAppliedDate());
            ps.setInt(7, emp.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }

    public static boolean deleteEmployee(int id) {
        String sql = "DELETE FROM employees WHERE id=?";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            return false;
        }
    }
} 
